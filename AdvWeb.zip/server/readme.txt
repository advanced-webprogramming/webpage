// install package
npm i express
npm i express-session
npm i mysql
npm i ejs

// start server
node server.js
