// install package
npm i express
npm i express-session
npm i mysql

// start server
node login.js
